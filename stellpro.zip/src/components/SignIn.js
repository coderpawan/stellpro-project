import React, { useState } from "react";
import {
  createUserWithEmailAndPassword,
  //   onAuthStateChanged,
  signInWithEmailAndPassword,
} from "firebase/auth";
import { auth } from "./firebase-config";
import { useNavigate } from "react-router-dom";

const SignIn = () => {
  const [togglepage, setTogglepage] = useState(false);
  const [registerEmail, setRegisterEmail] = useState("");
  const [registerPassword, setRegisterPassword] = useState("");
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [user, setUser] = useState({});
  const navigate = useNavigate();

  const HandleSignIn = () => {
    setTogglepage(!togglepage);
  };
  //   onAuthStateChanged(auth, (currentUser) => {
  //     setUser(currentUser);
  //   });

  const Register = async (e) => {
    e.preventDefault();
    createUserWithEmailAndPassword(auth, registerEmail, registerPassword)
      .then((userCredential) => {
        // Signed in
        setUser(userCredential.user);
        localStorage.setItem("user", user);
        // ...
      })
      .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
        console.log(errorCode, errorMessage);
        // ..
      });
    navigate("/");
  };
  const Login = async (e) => {
    e.preventDefault();
    signInWithEmailAndPassword(auth, loginEmail, loginPassword)
      .then((userCredential) => {
        // Signed in
        setUser(userCredential.user);
        // ...
      })
      .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
        console.log(errorCode, errorMessage);
      });
    navigate("/");
  };
  return (
    <div className="ml-1 mr-8">
      {!togglepage ? (
        <div className="">
          <div className="text-2xl font-bold mt-6">Sign In</div>
          <div className="mt-4">
            the below details to sign in your demdee's account
          </div>
          <div className="flex mt-6">
            <div className="bg-white text-emerald-500  border-black hover:border-black border-solid border-2 px-16 py-2 rounded-xl font-bold">
              Sign In with Email
            </div>
            <div className="bg-white ml-6 border-gray-100 hover:border-black border-solid border-2 px-16 py-2 rounded-xl font-bold">
              Sign In with OTP
            </div>
          </div>
          <form action="">
            <div className="text-xl font-bold mt-6">Email</div>
            <input
              onChange={(event) => {
                setLoginEmail(event.target.value);
              }}
              type="email"
              name="email"
              required
              placeholder="Enter your email address"
              className="w-full border-solid border-2 border-gray-100 px-3 py-2 mt-4"
            />
            <div className="text-xl font-bold mt-6">Password</div>
            <input
              onChange={(event) => {
                setLoginPassword(event.target.value);
              }}
              type="password"
              name="password"
              required
              placeholder="Enter your Password"
              className="w-full border-solid border-2 border-gray-100 px-3 py-2 mt-4"
            />
            <div className="text-sm mt-4">Forgot Password?</div>
            <button
              onClick={Login}
              className="px-10  cursor-pointer relative left-[40%] mt-4 py-2 rounded-2xl bg-emerald-500 font-bold text-sm hover:text-white hover:bg-orange"
            >
              SIGN IN
            </button>
          </form>

          <div className="flex mt-6 justify-center">
            <div className="text-sm">Don’t have an account? </div>
            <div
              onClick={HandleSignIn}
              className="text-orange font-bold text-sm hover:text-emerald-500 ml-1 cursor-pointer"
            >
              Sign Up For Free
            </div>
          </div>
          <div className="flex mt-6 justify-center">
            <div className="text-sm cursor-pointer">Are you a Therapist? </div>
          </div>
          <div className="text-sm mt-6">
            By submitting this form you agree to Demdee's privacy policy, terms
            of use and allow us to contact you for special offers and promotions
          </div>
        </div>
      ) : (
        <div className="">
          <div className="text-2xl font-bold mt-4">Create An Account</div>
          <div className="mt-2">
            Please fill the below details to register demdee's account
          </div>
          <form action="" className="">
            <div className="text-lg font-bold mt-4">Email</div>
            <input
              onChange={(event) => {
                setRegisterEmail(event.target.value);
              }}
              type="email"
              name="email"
              required
              placeholder="Enter your email address"
              className="w-full border-solid border-2 border-gray-100 px-3 py-1 mt-2 rounded-lg"
            />
            <div className="text-lg font-bold mt-6">Mobile Number</div>
            <input
              type="number"
              name="phone"
              required
              placeholder="Enter your Mobile Number"
              className="w-full border-solid border-2 border-gray-100 px-3 py-1 mt-2 rounded-lg"
            />
            <div className="text-lg font-bold mt-6">Country</div>
            <select
              name=""
              id=""
              required
              className="w-full border-solid border-2 border-gray-100 py-1 rounded-lg"
            >
              <option value="">Select a Country</option>
              <option value="+91">India (+91)</option>
              <option value="+61">Australia (+61)</option>
              <option value="+1">Canada (+1)</option>
              <option value="+49">Germany (+49)</option>
              <option value="+974">Qatar (+974)</option>
              <option value="+46">Sweden (+46)</option>
              <option value="+44">United Kingdom (+44)</option>
              <option value="+1">United States of America (USA) (+1)</option>
              <option value="+263">Zimbabwe (+263)</option>
            </select>
            <div className="text-lg font-bold mt-6">Password</div>
            <input
              onChange={(event) => {
                setRegisterPassword(event.target.value);
              }}
              type="password"
              name="password"
              required
              placeholder="Enter your Password"
              className="w-full border-solid border-2 border-gray-100 px-3 py-1 mt-2 rounded-lg"
            />
            <button
              onClick={Register}
              className="px-10 relative left-[40%] mt-10 py-2 rounded-2xl bg-emerald-500 font-bold text-sm hover:text-white hover:bg-orange cursor-pointer"
            >
              SIGN UP
            </button>
          </form>
          <div className="flex mt-6 justify-center">
            <div className="text-sm">Already have an account? </div>
            <div
              onClick={HandleSignIn}
              className="text-orange font-bold text-sm hover:text-emerald-500 ml-1 cursor-pointer"
            >
              Sign In
            </div>
          </div>
          {console.log(user.email)}
          <div className="flex mt-3 justify-center">
            <div className="text-sm  cursor-pointer">Are you a Therapist? </div>
          </div>
          <div className="text-sm mt-4">
            By submitting this form you agree to Demdee's privacy policy, terms
            of use and allow us to contact you for special offers and promotions
          </div>
        </div>
      )}
    </div>
  );
};

export default SignIn;
