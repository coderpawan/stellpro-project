import Consultation from "../images/consultation.jpg";
import OccupationalTherapy from "../images/occupational therapy.jpg";

const Data = [
  {
    id: 1,
    image: OccupationalTherapy,
    topic: "Does my child need Occupational Therapy?",
    date: "8 April,2022",
    tag: "Parenting",
  },
  {
    id: 2,
    image: Consultation,
    topic: "Parental Involvement In Online Speech Therapy",
    date: "March 21,2002",
    tag: "Parenting",
  },
  {
    id: 3,
    image: Consultation,
    topic: "Parental Involvement In Online Speech Therapy",
    date: "March 21,2002",
    tag: "Parenting",
  },
  {
    id: 4,
    image: Consultation,
    topic: "Parental Involvement In Online Speech Therapy",
    date: "March 21,2002",
    tag: "Parenting",
  },
  {
    id: 5,
    image: Consultation,
    topic: "Parental Involvement In Online Speech Therapy",
    date: "March 21,2002",
    tag: "Parenting",
  },
  {
    id: 6,
    image: Consultation,
    topic: "Parental Involvement In Online Speech Therapy",
    date: "March 21,2002",
    tag: "Parenting",
  },
  {
    id: 7,
    image: Consultation,
    topic: "Parental Involvement In Online Speech Therapy",
    date: "March 21,2002",
    tag: "Parenting",
  },
  {
    id: 8,
    image: Consultation,
    topic: "Parental Involvement In Online Speech Therapy",
    date: "March 21,2002",
    tag: "Parenting",
  },
  {
    id: 9,
    image: Consultation,
    topic: "Parental Involvement In Online Speech Therapy",
    date: "March 21,2002",
    tag: "Parenting",
  },
];

export default Data;
