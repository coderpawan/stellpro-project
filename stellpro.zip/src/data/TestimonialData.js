import Shubhangi from "../images/Shubhangi.jpg";
const Data = [
  {
    id: 1,
    picture: Shubhangi,
    name: "Shubhangi",
    position: "Google",
    about:
      "Lörem ipsum farat hexanade av logokrati, sament. Groma kaheten i räddningskort sprejgodis. Gigalig nit digt koscheria osende. ",
  },
  {
    id: 2,
    picture: Shubhangi,
    name: "Shubhangi",
    position: "Google",
    about:
      "Lörem ipsum farat hexanade av logokrati, sament. Groma kaheten i räddningskort sprejgodis. Gigalig nit digt koscheria osende. ",
  },
  {
    id: 3,
    picture: Shubhangi,
    name: "Shubhangi",
    position: "Google",
    about:
      "Lörem ipsum farat hexanade av logokrati, sament. Groma kaheten i räddningskort sprejgodis. Gigalig nit digt koscheria osende. ",
  },
  {
    id: 4,
    picture: Shubhangi,
    name: "Shubhangi",
    position: "Google",
    about:
      "Lörem ipsum farat hexanade av logokrati, sament. Groma kaheten i räddningskort sprejgodis. Gigalig nit digt koscheria osende. ",
  },
  {
    id: 5,
    picture: Shubhangi,
    name: "Shubhangi",
    position: "Google",
    about:
      "Lörem ipsum farat hexanade av logokrati, sament. Groma kaheten i räddningskort sprejgodis. Gigalig nit digt koscheria osende. ",
  },
  {
    id: 6,
    picture: Shubhangi,
    name: "Shubhangi",
    position: "Google",
    about:
      "Lörem ipsum farat hexanade av logokrati, sament. Groma kaheten i räddningskort sprejgodis. Gigalig nit digt koscheria osende. ",
  },
  {
    id: 7,
    picture: Shubhangi,
    name: "Shubhangi",
    position: "Google",
    about:
      "Lörem ipsum farat hexanade av logokrati, sament. Groma kaheten i räddningskort sprejgodis. Gigalig nit digt koscheria osende. ",
  },
];
export default Data;
