const Data = [
  {
    id: 1,
    location: "Ukhra",
    city: "Bardhaman",
    therapy: "Occupational Therapy",
  },
  {
    id: 2,
    location: "Ukhra",
    city: "Bardhaman",
    therapy: "Speech Therapy",
  },
  {
    id: 3,
    location: "Varanasi",
    city: "UttarPradesh",
    therapy: "Occupational Therapy",
  },
  {
    id: 4,
    location: "Bakhri",
    city: "Begusarai",
    therapy: "Speech Therapy",
  },
  {
    id: 5,
    location: "Malad",
    city: "Mumbai",
    therapy: "Mind Therapy",
  },
  {
    id: 6,
    location: "Malad",
    city: "Mumbai",
    therapy: "Occupational Therapy",
  },
  {
    id: 7,
    location: "Khar",
    city: "Mumbai",
    therapy: "Speech Therapy",
  },
  {
    id: 8,
    location: "Andheri",
    city: "Mumbai",
    therapy: "Occupational Therapy",
  },
  {
    id: 9,
    location: "Kandivali",
    city: "Mumbai",
    therapy: "Occupational Therapy",
  },
];

export default Data;
