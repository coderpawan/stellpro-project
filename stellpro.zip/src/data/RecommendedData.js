import Consultation from "../images/consultation.jpg";

const Recommended = [
  {
    id: 1,
    image: Consultation,
    description: "Things You Can Do on Good Friday | 5 Good Friday Traditions",
  },
  {
    id: 2,
    image: Consultation,
    description: "Things You Can Do on Good Friday | 5 Good Friday Traditions",
  },
  {
    id: 3,
    image: Consultation,
    description: "Things You Can Do on Good Friday | 5 Good Friday Traditions",
  },
  {
    id: 4,
    image: Consultation,
    description: "Things You Can Do on Good Friday | 5 Good Friday Traditions",
  },
];

export default Recommended;
