import React from "react";
import Navbar from "../components/Navbar";

const Community = () => {
  return (
    <div>
      <Navbar />
      <div className="text-center pt-20 text-2xl text-red-500">Coming Soon</div>
    </div>
  );
};

export default Community;
